$(document).ready(function(){
    $(".owl-carousel").owlCarousel({
        items:1,
        autoplay: true,
        autoplayTimeout: 5000,
        loop: true
    });
});